﻿
namespace Cinema.DataProcessor.ExportDto
{
    public class CustomerMovieExportDto
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Balance { get; set; }

    }
}
