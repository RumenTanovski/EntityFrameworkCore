﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-SRL2A15\SQLEXPRESS;Database=Cinema;Trusted_Connection=True";
    }
}
