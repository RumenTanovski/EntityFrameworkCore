﻿using System.Xml.Serialization;

namespace CarDealer.Dtos.Export
{
    [XmlType("sale")]
    public class ExportSalesWithDiscountDto
    {
        [XmlElement(ElementName ="car")]
        public ExportCarWithDiscount CarDiscount { get; set; }

        [XmlElement(ElementName ="discount")]
        public decimal Discount { get; set; }

        [XmlElement(ElementName ="customer-name")]
        public string Name { get; set; }

        [XmlElement(ElementName ="price")]
        public decimal Price { get; set; }

        [XmlElement(ElementName ="price-with-discount")]
        public decimal PriceWithDiscount { get; set; }

    }
}
