﻿namespace P01_StudentSystem.Data.Models
{
    public enum ContentType
    {
        Aplication = 0,
        Pdf= 1,
        Zip=2
    }
}