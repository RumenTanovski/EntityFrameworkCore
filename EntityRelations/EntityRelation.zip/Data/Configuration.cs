﻿namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string ConectionString =
            @"Server=DESKTOP-SRL2A15\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";

    }
}
