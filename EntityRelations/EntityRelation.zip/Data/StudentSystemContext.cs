﻿using Microsoft.EntityFrameworkCore;
using P01_StudentSystem.Data.Models;


namespace P01_StudentSystem.Data
{
    public class StudentSystemContext : DbContext
    {
        public StudentSystemContext()
        {
        }

        public StudentSystemContext(DbContextOptions options)
            : base(options)
        {
        }

        public DbSet<Course> Courses { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Homework> HomeworkSubmissions { get; set; }
        public DbSet<StudentCourse> StudentCourses { get; set; }
        public DbSet<Resource> Resources { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder
                                                optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer
                    (Configuration.ConectionString);
            }
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder
                                                modelBuilder)
        {
            modelBuilder.Entity<Student>(entity =>
            {
                //Primary Key
                entity.HasKey(p => p.StudentId);

                entity
                    .Property(p => p.Name)
                    .HasMaxLength(100)
                    .IsRequired(true)
                    .IsUnicode(true);

                entity
                    .Property(p => p.PhoneNumber)
                    .IsUnicode(false)
                    .IsRequired(false)
                    .HasColumnType("CHAR(10)");

                entity
                    .Property(p => p.RegisteredOn)
                    .IsRequired(true);

                entity
                        .Property(p => p.Birthday)
                        .IsRequired(false);

            });

            modelBuilder.Entity<Course>(entity =>
            {
                entity.HasKey(p => p.CourseId);

                entity
                    .Property(p => p.Name)
                    .HasMaxLength(80)
                    .IsRequired(true)
                    .IsUnicode(true);

                entity
                    .Property(p => p.Description)
                    .IsRequired(false)
                    .IsUnicode(true);                    

                entity
                .Property(p => p.StartDate)
                .IsRequired(true);

                entity
                .Property(p => p.EndDate)
                .IsRequired(true);

                entity
                .Property(p => p.Price)
                .IsRequired(true);
            });


            modelBuilder.Entity<Homework>(entity =>
            {
                entity.HasKey(p => p.HomeworkId);

                entity
                .Property(p => p.Content)
                .IsRequired(true)
                .IsUnicode(false);

                entity
                .Property(p => p.ContentType)
                .IsRequired(true);

                entity
                .Property(p => p.SubmissionTime)
                .IsRequired(true);

                entity
                .HasOne(s => s.Student)
                .WithMany(p => p.HomeworkSubmissions)
                .HasForeignKey(s => s.StudentId)
                .OnDelete(DeleteBehavior.Restrict); 

                entity
                .HasOne(s => s.Course)
                .WithMany(p => p.HomeworkSubmissions)
                .HasForeignKey(s => s.CourseId)
                .OnDelete(DeleteBehavior.Restrict); 

            });

            modelBuilder.Entity<Resource>(entity =>
            {
                entity.HasKey(k => k.ResourceId);

                entity
                .Property(p => p.Name)
                .HasMaxLength(50)
                .IsUnicode(true)
                .IsRequired(true);

                entity
                .Property(p => p.Url)
                .IsUnicode(false)
                .IsRequired(true);

                entity
                .Property(p => p.ResourceType)
                .IsRequired(true);

                entity
                .HasOne(s => s.Course)
                .WithMany(p => p.Resources)
                .HasForeignKey(s => s.CourseId)
                .OnDelete(DeleteBehavior.Restrict); 

            });

            modelBuilder.Entity<StudentCourse>(entity =>
            {
                entity.HasKey(k => new { k.StudentId, k.CourseId });

                entity
                .HasOne(s => s.Student)
                .WithMany(p => p.CourseEnrollments)
                .HasForeignKey(s => s.StudentId)
                .OnDelete(DeleteBehavior.Restrict); ;

                entity
                .HasOne(s => s.Course)
                .WithMany(p => p.StudentsEnrolled)
                .HasForeignKey(s => s.CourseId)
                .OnDelete(DeleteBehavior.Restrict); ;
            });

        }
    }
}
